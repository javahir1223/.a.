let container = document.getElementById('container')
		
toggle = () => {
	container.classList.toggle('sign-in')
	container.classList.toggle('sign-up')
}

setTimeout(() => {
	container.classList.add('sign-in')
}, 200)

let group = document.querySelector('.inputt')
let button = document.querySelector('.button')
let pass = document.querySelector('.password')

button.addEventListener('click', () => {
	console.log(group.value)
	console.log(pass.value)

	const users = JSON.parse(localStorage.getItem('users')) || []
	const user = users.find(
		user => user.username === group.value && user.password === pass.value
	)

	if (user) {
		// alert('Keyingi pagega otish')
		window.location.href = "../home page/index.html"
	} else {
		let warning = document.querySelector('.war')
		warning.innerHTML = `<p class="warning">Login yoki Parol xato</p>`
	}
})

let user = document.querySelector('.user')
let surname = document.querySelector('.surname')
let email = document.querySelector('.email')
let word = document.querySelector('.word')
let confirm = document.querySelector('.confirm')
let genderRadioButtons = document.getElementsByName('gender')
let button2 = document.querySelector('.up')

button2.addEventListener('click', () => {
	console.log(user.value)
	console.log(surname.value)
	console.log(email.value)
	console.log(word.value)
	console.log(confirm.value)

	let gender
	for (let i = 0; i < genderRadioButtons.length; i++) {
		if (genderRadioButtons[i].checked) {
			gender = genderRadioButtons[i].value
			break
		}
	window.location.href = '../home page/index.html'
	}

	const newUser = {
		id: Math.random() * 100,
		username: user.value,
		surname: surname.value,
		email: email.value,
		password: word.value,
		confirm: confirm.value,
		gender: gender,
	}

	let users = JSON.parse(localStorage.getItem('users')) || []
	users.push(newUser)
	localStorage.setItem('users', JSON.stringify(users))
})


