document.addEventListener('DOMContentLoaded', () => {
    const reportForm = document.getElementById('reportForm');

    loadReports();

    reportForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const imageInput = document.getElementById('image');
        const name = document.getElementById('name').value;
        const location = document.getElementById('location').value;
        const description = document.getElementById('description').value;

        const reader = new FileReader();
        reader.onload = function(e) {
            const imageData = e.target.result;

            const report = {
                name,
                location,
                description,
                image: imageData
            };

            saveReport(report);

            reportForm.reset();

            displayReports();
        };

        if (imageInput.files[0]) {
            reader.readAsDataURL(imageInput.files[0]);
        }
    });

    function saveReport(report) {
        let reports = JSON.parse(localStorage.getItem('reports')) || [];

        reports.push(report);

        localStorage.setItem('reports', JSON.stringify(reports));
    }

    function loadReports() {
        const reports = JSON.parse(localStorage.getItem('reports')) || [];

        reports.forEach(report => {
            displayReport(report);
        });
    }

    function displayReport(report) {
        const reportContainer = document.createElement('div');
        reportContainer.className = 'report-card';
        reportContainer.innerHTML = `
            <h2>${report.name}</h2>
            <p><strong>Location:</strong> ${report.location}</p>
            <p><strong>Description:</strong> ${report.description}</p>
            <img src="${report.image}" alt="${report.name}" style="max-width: 100%; height: auto;">
        `;
    }

    function displayReports() {
        document.body.querySelectorAll('.report-card').forEach(card => card.remove());

        loadReports();
    }
});


const contactBtn = document.getElementById('contactButton');
const contactBtn2 = document.getElementById('contactButton2')
const closeContactModalBtn = document.querySelector('.close-contact');

// Open the contact modal
contactBtn.onclick = function () {
    contactModal.style.display = 'block';
}

contactBtn2.onclick = function () {
    contactModal.style.display = 'block';
}
// Close the contact modal
closeContactModalBtn.onclick = function () {
    contactModal.style.display = 'none';
}

window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
    if (event.target == contactModal) {
        contactModal.style.display = 'none';
    }
}