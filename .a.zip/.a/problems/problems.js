let data = [
    {
        "id": 1,
        "nomi": "O‘rmonlarning kesilishi",
        "tavsifi": "Insonlar tomonidan keng ko‘lamda o‘rmonlarning kesilishi, bu esa biologik xilma-xillikning yo‘qolishiga va ekotizimlarning buzilishiga olib keladi.",
        "foto": "https://avatars.mds.yandex.net/i?id=bf3a39cd7e533782e7d3a97b8e501baaf0098ee658ee492d-12497467-images-thumbs&n=13",
        "donationSum": 10000,
        "amountEarned": 2500
    },
    {
        "id": 2,
        "nomi": "Sanoat ifloslanishi",
        "tavsifi": "Zavodlar tomonidan katta miqdorda chiqindi va ifloslantiruvchi moddalar havo, suv va tuproqqa chiqarilishi, bu esa ekologik va sog‘liq muammolariga olib keladi.",
        "foto": "https://avatars.mds.yandex.net/i?id=7154f2a1d3693ceb7ed1613dd753a18df94e9a1a-5501633-images-thumbs&n=13",
        "donationSum": 8000,
        "amountEarned": 1200
    },
    {
        "id": 3,
        "nomi": "Plastik ifloslanishi",
        "tavsifi": "Yer yuzida plastik buyumlar va zarrachalarning to‘planishi, bu esa yovvoyi hayot, yashash muhitiga va insonlarga salbiy ta'sir ko‘rsatadi.",
        "foto": "https://avatars.mds.yandex.net/i?id=15225d91b8c23a8d875e25ec4dbf7d12f9ba0151-10836362-images-thumbs&n=13",
        "donationSum": 7500,
        "amountEarned": 1100
    },
    {
        "id": 4,
        "nomi": "Baliqchilikning haddan tashqari ko‘payishi",
        "tavsifi": "Baliq zaxiralarining qayta tiklanishidan tezroq sur’atda tutib olinishi, bu esa dengiz ekotizimlarining qulashiga olib keladi.",
        "foto": "https://avatars.mds.yandex.net/i?id=bf60fb19e4c59c937780aa1db179cde9792e4f14-5654477-images-thumbs&n=13",
        "donationSum": 9200,
        "amountEarned": 2000
    },
    {
        "id": 5,
        "nomi": "Suv ifloslanishi",
        "tavsifi": "Odamlar tomonidan amalga oshirilgan faoliyatlar, masalan, sanoat chiqindilarini tashlash, suv havzalari (ko‘llar, daryolar, okeanlar)ning ifloslanishiga olib keladi va suv hayoti hamda ekotizimlarga zarar yetkazadi.",
        "foto": "https://avatars.mds.yandex.net/i?id=fe06729847891a5fb50849c023222a1e9bccc106-8294270-images-thumbs&n=13",
        "donationSum": 900,
        "amountEarned": 100
    },
    {
        "id": 6,
        "nomi": "Shahar ifloslanishi",
        "tavsifi": "Shahar hududlarida transport, sanoat va maishiy chiqindilar tufayli havo, suv va tuproqning ifloslanishi.",
        "foto": "https://avatars.mds.yandex.net/i?id=362c8b74d1599c94b1af343c96e794925549478a-11254239-images-thumbs&n=13",
        "donationSum": 800,
        "amountEarned": 200
    }
];

const divs = document.querySelector('.divs');
const modal = document.getElementById('modal');
const contactModal = document.getElementById('contactModal');
const btn = document.getElementById('openModal');
const contactBtn = document.getElementById('contactButton');
const contactBtn2 = document.getElementById('contactButton2')
const closeDonationModalBtn = document.querySelector('.close');
const closeContactModalBtn = document.querySelector('.close-contact');
const templateForm = document.getElementById('templateForm');
const contactForm = document.getElementById('contactForm');

// Render initial data

data.forEach(value => {
    divs.innerHTML += `
        <div class ="div${value.id}">
            <img src="${value.foto}" alt="${value.nomi}" style="max-width: 100%; height: auto;">
            <br>
            <h2>${value.nomi}</h2>
            <p>${value.tavsifi}</p>
            <p class="p">Donat summasi: $${value.donationSum.toFixed(2)}</p>
            <p class="ps">Ishlangan summasi: $<span class="amount-earned">${value.amountEarned.toFixed(2)}</span></p>
            <div class="progress-bar">
                <div class="progress-bar-filled" style="width: ${(value.amountEarned / value.donationSum) * 100}%">
                    ${Math.round((value.amountEarned / value.donationSum) * 100)}%
                </div>
            </div>
            <button class="donat" onclick="makeDonation(this, ${value.donationSum})">Donat qilish</button>
        </div>
    `;
});

// Open the donation modal
btn.onclick = function () {
    modal.style.display = 'block';
}

// Open the contact modal
contactBtn.onclick = function () {
    contactModal.style.display = 'block';
}
contactBtn2.onclick = function () {
    contactModal.style.display = 'block';
}
// Close the donation modal
closeDonationModalBtn.onclick = function () {
    modal.style.display = 'none';
}

// Close the contact modal
closeContactModalBtn.onclick = function () {
    contactModal.style.display = 'none';
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
    if (event.target == contactModal) {
        contactModal.style.display = 'none';
    }
}

// Handle donation form submission
templateForm.onsubmit = function (event) {
    event.preventDefault();

    // Get form values
    const photo = document.getElementById('photo').value;
    const name = document.getElementById('name').value;
    const description = document.getElementById('description').value;
    const donationSum = parseFloat(document.getElementById('donationSum').value);
    const amountEarned = parseFloat(document.getElementById('amountEarned').value);

    // Create a new template div
    const newDiv = document.createElement('div');
    newDiv.innerHTML = `
        <div>
            <img src="${photo}" alt="${name}" style="max-width: 100%; height: auto;">
            <br>
            <h2>${name}</h2>
            <p>${description}</p>
            <p>Donation Sum: $${donationSum.toFixed(2)}</p>
            <p>Amount Earned: $<span class="amount-earned">${amountEarned.toFixed(2)}</span></p>
            <div class="progress-bar">
                <div class="progress-bar-filled" style="width: ${(amountEarned / donationSum) * 100}%">
                    ${Math.round((amountEarned / donationSum) * 100)}%
                </div>
            </div>
            <button onclick="makeDonation(this, ${donationSum})">Donate</button>
        </div>
    `;

    // Append new template to the divs container
    divs.appendChild(newDiv);

    // Clear and close the modal
    templateForm.reset();
    modal.style.display = 'none';
}

// Handle contact form submission
contactForm.onsubmit = function (event) {
    event.preventDefault();
    // Handle form submission logic
    contactForm.reset();
    contactModal.style.display = 'none';
}

// Function to handle donations
function makeDonation(button, goal) {
    let card = prompt('Karta raqamini kiriting:')
    if (card.length === 19) {
        let conf = confirm('Ishonchingiz komilmi?')
        if (conf) {
            const donationAmount = parseFloat(prompt("Xayriya miqdorini kiriting:"));
            if (donationAmount && !isNaN(donationAmount)) {
                const parentDiv = button.parentElement;
                const amountEarnedSpan = parentDiv.querySelector('.amount-earned');
                let currentAmount = parseFloat(amountEarnedSpan.textContent);

                // Update amount earned
                currentAmount += donationAmount;
                amountEarnedSpan.textContent = currentAmount.toFixed(2);

                // Update progress bar
                const progressBarFilled = parentDiv.querySelector('.progress-bar-filled');
                const progressPercentage = Math.min((currentAmount / goal) * 100, 100);
                progressBarFilled.style.width = `${progressPercentage}%`;
                progressBarFilled.textContent = `${Math.round(progressPercentage)}%`;


                alert(`Sizning ehson uchun rahmat $${donationAmount}.`);
            } else {
                alert("Iltimos, haqiqiy xayriya miqdorini kiriting.");
            }
        }
    }else{
        alert('Xaqiqiy cartani nomerini kiriting')
    }


}
